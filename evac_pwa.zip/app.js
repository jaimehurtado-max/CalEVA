// Simple PWA + Calculator logic
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const btn = document.getElementById('installBtn');
  btn.hidden = false;
  btn.addEventListener('click', async () => {
    btn.hidden = true;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
  });
});

// Service worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js');
  });
}

const levelsTableBody = document.querySelector('#levelsTable tbody');
const resultsDiv = document.getElementById('results');
const resultsCard = document.getElementById('resultsCard');
const summaryCard = document.getElementById('summaryCard');
const rsetSpan = document.getElementById('rset');

function addLevelRow(data = {
  nombre: 'Piso',
  ocupantes: 50,
  salidas: 1,
  ruta: 'Directa',
  dH: 10,
  bwCorr: 1.5,
  bwDoor: 1.2,
  dStair: 0,
  bwStair: 0
}) {
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input value="${data.nombre}"></td>
    <td><input type="number" min="1" step="1" value="${data.ocupantes}"></td>
    <td><input type="number" min="1" step="1" value="${data.salidas}"></td>
    <td>
      <select>
        <option ${data.ruta==='Directa'?'selected':''}>Directa</option>
        <option ${data.ruta==='Por escalera'?'selected':''}>Por escalera</option>
      </select>
    </td>
    <td><input type="number" min="0" step="1" value="${data.dH}"></td>
    <td><input type="number" min="0.5" step="0.1" value="${data.bwCorr}"></td>
    <td><input type="number" min="0.5" step="0.1" value="${data.bwDoor}"></td>
    <td><input type="number" min="0" step="1" value="${data.dStair}"></td>
    <td><input type="number" min="0" step="0.1" value="${data.bwStair}"></td>
    <td><button class="del">✕</button></td>
  `;
  tr.querySelector('.del').addEventListener('click', () => tr.remove());
  levelsTableBody.appendChild(tr);
}

document.getElementById('addLevel').addEventListener('click', () => addLevelRow());

// Seed with 3 default levels
addLevelRow({nombre:'Piso 3', ocupantes:120, salidas:1, ruta:'Por escalera', dH:25, bwCorr:1.8, bwDoor:1.2, dStair:35, bwStair:1.5});
addLevelRow({nombre:'Piso 2', ocupantes:100, salidas:1, ruta:'Por escalera', dH:20, bwCorr:1.8, bwDoor:1.2, dStair:25, bwStair:1.5});
addLevelRow({nombre:'Piso 1', ocupantes:80, salidas:2, ruta:'Directa', dH:15, bwCorr:2.0, bwDoor:1.5, dStair:0, bwStair:0});

function readParams() {
  const vH = parseFloat(document.getElementById('vH').value) || 1.2;
  const vS = parseFloat(document.getElementById('vS').value) || 0.7;
  const qDoor = parseFloat(document.getElementById('qDoor').value) || 1.3;
  const qCorr = parseFloat(document.getElementById('qCorr').value) || 1.5;
  const qStair = parseFloat(document.getElementById('qStair').value) || 1.1;
  const tAlarm = parseFloat(document.getElementById('tAlarm').value) || 30;
  const tPre = parseFloat(document.getElementById('tPre').value) || 60;
  return { vH, vS, qDoor, qCorr, qStair, tAlarm, tPre };
}

function readLevels() {
  const rows = [...levelsTableBody.querySelectorAll('tr')];
  return rows.map(r => {
    const [nombre, ocup, sal, ruta, dH, bwCorr, bwDoor, dStair, bwStair] = [...r.querySelectorAll('input, select')].map(el => el.value);
    return {
      nombre,
      ocupantes: Number(ocup),
      salidas: Math.max(1, Number(sal)||1),
      ruta,
      dH: Number(dH),
      bwCorr: Number(bwCorr),
      bwDoor: Number(bwDoor),
      dStair: Number(dStair),
      bwStair: Number(bwStair)
    };
  });
}

function calcular() {
  const p = readParams();
  const niveles = readLevels();

  const res = [];
  let maxTotal = 0;

  for (const n of niveles) {
    const vH = Math.max(0.01, p.vH);
    const vS = Math.max(0.01, p.vS);
    const qDoor = Math.max(0.01, p.qDoor);
    const qStair = Math.max(0.01, p.qStair);
    const tAlarm = p.tAlarm;
    const tPre = p.tPre;

    const tH = (n.dH || 0) / vH;
    const tS = (n.ruta === 'Por escalera') ? (n.dStair || 0) / vS : 0;

    let capacidad;
    if (n.ruta === 'Por escalera') {
      capacidad = qStair * Math.max(n.bwStair || 0, n.bwDoor || 0.01) * n.salidas;
    } else {
      capacidad = qDoor * (n.bwDoor || 0.01) * n.salidas;
    }
    const tQueue = (n.ocupantes || 0) / Math.max(0.01, capacidad);

    const tTotal = tAlarm + tPre + tH + tS + tQueue;
    maxTotal = Math.max(maxTotal, tTotal);

    res.push({
      nombre: n.nombre,
      ruta: n.ruta,
      ocupantes: n.ocupantes,
      tAlarm, tPre, tH, tS, tQueue, tTotal
    });
  }

  // Render
  resultsDiv.innerHTML = res.map(r => `
    <div class="row">
      <div class="title">${r.nombre} — ${r.ruta}</div>
      <div class="line">t_alarma: <b>${r.tAlarm.toFixed(0)}</b> s · t_premov: <b>${r.tPre.toFixed(0)}</b> s</div>
      <div class="line">t_horiz: <b>${r.tH.toFixed(0)}</b> s · t_escal: <b>${r.tS.toFixed(0)}</b> s · t_cola: <b>${r.tQueue.toFixed(0)}</b> s</div>
      <div class="line total">t_total: <b>${r.tTotal.toFixed(0)}</b> s</div>
    </div>
  `).join('');
  rsetSpan.textContent = maxTotal.toFixed(0);
  resultsCard.hidden = res.length === 0;
  summaryCard.hidden = res.length === 0;
}

document.getElementById('calc').addEventListener('click', calcular);

// Local persistence
document.getElementById('save').addEventListener('click', () => {
  const data = { params: readParams(), niveles: readLevels() };
  localStorage.setItem('evac_data', JSON.stringify(data));
  alert('Guardado localmente.');
});
document.getElementById('load').addEventListener('click', () => {
  const s = localStorage.getItem('evac_data');
  if (!s) { alert('No hay datos guardados.'); return; }
  const data = JSON.parse(s);
  document.getElementById('vH').value = data.params.vH;
  document.getElementById('vS').value = data.params.vS;
  document.getElementById('qDoor').value = data.params.qDoor;
  document.getElementById('qCorr').value = data.params.qCorr;
  document.getElementById('qStair').value = data.params.qStair;
  document.getElementById('tAlarm').value = data.params.tAlarm;
  document.getElementById('tPre').value = data.params.tPre;

  // Reset table
  levelsTableBody.innerHTML = '';
  for (const n of data.niveles) addLevelRow(n);
  alert('Datos cargados.');
});
